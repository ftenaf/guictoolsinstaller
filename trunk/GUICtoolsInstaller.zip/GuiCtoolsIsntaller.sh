#!/bin/sh
#
################ FILE IDENTIFICATION ################################
#
# Name: GuiCtoolsInstaller.sh
# Description:Really simple Script to launch GuiCtolsInstaller.jar
#
#
# Creation Date: 15/04/2012
#
# Efemeride : 15/04/1955: Ray Kroc open firts McDonald's restaurant in Des Plaines, Illinois.
#
# Author: JUAN-JOSÉ ORTILLES
# @ FEEL FREE TO ADAPT THIS SHELL TO YOUR NECESSITIES.
# @ THEN ADD YOUR NAME TO THE AUTHOR(S) AND THE MODIFICATION DATE. 
#######################################################################

java -jar GuiCToolsIsntaller.jar 
