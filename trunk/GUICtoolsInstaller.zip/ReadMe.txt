GuiCtoolsInstaller
This tool is a graphical tool to install the Ctools  + Saiku  plugins in Pentaho BI server.
This tool is based on ctoolsinstaller by Pedro Alves. (https://github.com/pmalves/ctools-installer)
This tool is developed (at this moment by Juan José Ortilles)
This tool is distributed under GNU GPL license.

To use this GUI just  run: 
GuiCtoolsInstaller.sh if you are in *nix 
GuiCtoolsInstaller.bat if you are in windows
or double click on the auto executable GuiCToolsInstaller.jar 

If you have any question you can contact me jortilles@gmail.com